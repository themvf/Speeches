python -m pglite %*
